<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include_once '../config/database.php';
include_once '../config/helpers.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$id = (int)($_GET['id'] ?? 0);
$query = mysqli_query($conn, "SELECT * FROM tb_produk WHERE id = $id LIMIT 1");
$data = $query ? mysqli_fetch_assoc($query) : null;
if (!$data) {
    wg_flash_redirect('produk.php', 'Produk tidak ditemukan.');
}

$kategori_options = wg_get_categories($conn);
$nama_p = $data['nama'] ?? '';
$harga_p = (int)($data['harga'] ?? 0);
$stok_p = (int)($data['stok'] ?? 0);
$desk_p = $data['deskripsi'] ?? '';
$kategori_p = $data['kategori'] ?? '';
$gambar_lama = !empty($data['poto']) ? $data['poto'] : ($data['gambar'] ?? '');
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_produk = trim($_POST['nama'] ?? '');
    $harga = max(0, (int)($_POST['harga'] ?? 0));
    $stok = max(0, (int)($_POST['stok'] ?? 0));
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $link_gambar = trim($_POST['link_gambar'] ?? '');
    $nama_file_gambar = $gambar_lama;

    $valid_kategori = false;
    foreach ($kategori_options as $kat) {
        if ($kat['nama_kategori'] === $kategori) { $valid_kategori = true; break; }
    }
    if ($nama_produk === '' || !$valid_kategori) {
        $error = 'Nama produk dan kategori wajib valid.';
    }

    if (!$error && isset($_FILES['file_gambar']) && $_FILES['file_gambar']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['file_gambar']['error'] !== UPLOAD_ERR_OK) {
            $error = 'Upload gambar gagal.';
        } else {
            $ekstensi = strtolower(pathinfo($_FILES['file_gambar']['name'], PATHINFO_EXTENSION));
            if (!in_array($ekstensi, ['jpg','jpeg','png','webp'], true) || @getimagesize($_FILES['file_gambar']['tmp_name']) === false) {
                $error = 'File gambar harus JPG, PNG, atau WEBP yang valid.';
            } else {
                $folder = '../assets/img/';
                if (!is_dir($folder)) mkdir($folder, 0755, true);
                $baru = 'prod_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $ekstensi;
                if (move_uploaded_file($_FILES['file_gambar']['tmp_name'], $folder . $baru)) {
                    $nama_file_gambar = $baru;
                } else {
                    $error = 'Gambar baru tidak dapat disimpan.';
                }
            }
        }
    } elseif (!$error && $link_gambar !== '') {
        if (!filter_var($link_gambar, FILTER_VALIDATE_URL)) $error = 'URL gambar tidak valid.';
        else $nama_file_gambar = $link_gambar;
    }

    if (!$error) {
        $nama_sql = mysqli_real_escape_string($conn, $nama_produk);
        $desk_sql = mysqli_real_escape_string($conn, $deskripsi);
        $kat_sql = mysqli_real_escape_string($conn, $kategori);
        $img_sql = mysqli_real_escape_string($conn, $nama_file_gambar);
        $update = mysqli_query($conn, "UPDATE tb_produk SET nama='$nama_sql', harga=$harga, stok=$stok, deskripsi='$desk_sql', poto='$img_sql', kategori='$kat_sql' WHERE id=$id");
        if ($update) {
            if ($nama_file_gambar !== $gambar_lama && $gambar_lama !== '' && !filter_var($gambar_lama, FILTER_VALIDATE_URL)) @unlink('../assets/img/' . basename($gambar_lama));
            echo "<script>alert('Produk berhasil diperbarui.'); window.location='produk.php';</script>";
            exit;
        }
        $error = 'Gagal memperbarui produk.';
        if ($nama_file_gambar !== $gambar_lama && $nama_file_gambar !== '' && !filter_var($nama_file_gambar, FILTER_VALIDATE_URL)) @unlink('../assets/img/' . basename($nama_file_gambar));
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk - Wargt25 Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body class="bg-light">
<div id="wg-preloader"><div class="text-center"><div class="wg-loader-mark">Wargt<span>25</span></div><div class="wg-loader-bar"></div></div></div>
<nav class="navbar navbar-expand-lg navbar-dark shadow-sm navbar-wargt admin-nav"><div class="container"><div class="d-flex align-items-center gap-2"><a class="navbar-brand fw-bold font-display m-0" href="index.php">Wargt25 <span style="color:#a67c52;">Admin</span></a><a href="../index.php" target="_blank" class="btn btn-sm rounded-pill px-3 fw-semibold" style="background-color:rgba(255,255,255,.12);color:#fff;border:1px solid rgba(255,255,255,.35);"><i class="bi bi-eye me-1"></i> Lihat Sebagai Pelanggan</a></div><a href="produk.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Kembali ke Produk</a></div></nav>
<div class="container my-5" style="max-width:650px;"><div class="card admin-card border-0 shadow-sm rounded-4 p-4 bg-white">
<h5 class="font-display fw-bold mb-3" style="color:#2b302a;">Edit Detail Produk &amp; Gambar</h5>
<?php if ($error): ?><div class="alert alert-danger py-2 small"><?= htmlspecialchars($error); ?></div><?php endif; ?>
<form action="" method="POST" enctype="multipart/form-data">
<div class="mb-3"><label class="form-label small fw-semibold">Nama Produk</label><input type="text" name="nama" class="form-control form-control-sm" value="<?= htmlspecialchars($nama_p); ?>" required></div>
<div class="row"><div class="col-md-6 mb-3"><label class="form-label small fw-semibold">Harga (Rp)</label><input type="number" min="0" name="harga" class="form-control form-control-sm" value="<?= $harga_p; ?>" required></div><div class="col-md-6 mb-3"><label class="form-label small fw-semibold">Stok</label><input type="number" min="0" name="stok" class="form-control form-control-sm" value="<?= $stok_p; ?>" required></div></div>
<div class="mb-3"><label class="form-label small fw-semibold">Kategori Menu</label><select name="kategori" class="form-select form-select-sm" required><option value="">-- Pilih Kategori --</option><?php foreach($kategori_options as $kat): ?><option value="<?= htmlspecialchars($kat['nama_kategori']); ?>" <?= $kategori_p === $kat['nama_kategori'] ? 'selected' : ''; ?>><?= htmlspecialchars($kat['nama_kategori']); ?></option><?php endforeach; ?></select></div>
<div class="mb-3"><label class="form-label small fw-semibold">Gambar Saat Ini</label><div><?php if($gambar_lama): ?><img src="<?= htmlspecialchars(wg_product_image_admin($gambar_lama)); ?>" alt="Preview" class="rounded border" style="width:80px;height:80px;object-fit:cover" onerror="this.style.display='none'"><?php else: ?><span class="text-muted small">Belum ada gambar</span><?php endif; ?></div></div>
<div class="mb-3"><label class="form-label small fw-semibold">Ganti Gambar dari Komputer</label><input type="file" name="file_gambar" class="form-control form-control-sm" accept="image/jpeg,image/png,image/webp"></div>
<div class="mb-3"><label class="form-label small fw-semibold">Atau Ganti dengan URL</label><input type="url" name="link_gambar" class="form-control form-control-sm" placeholder="https://..."></div>
<div class="mb-4"><label class="form-label small fw-semibold">Deskripsi</label><textarea name="deskripsi" class="form-control form-control-sm" rows="3"><?= htmlspecialchars($desk_p); ?></textarea></div>
<div class="d-flex justify-content-end gap-2"><a href="produk.php" class="btn btn-sm btn-light px-4 rounded-pill">Batal</a><button type="submit" class="btn btn-sm text-white px-4 rounded-pill" style="background:#273526;">Simpan Perubahan</button></div>
</form></div></div>
<button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script><script src="../assets/js/theme.js"></script>
</body></html>
