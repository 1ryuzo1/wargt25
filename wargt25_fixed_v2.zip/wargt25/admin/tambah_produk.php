<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include_once '../config/database.php';
include_once '../config/helpers.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}

$pesan_error = '';
$pesan_sukses = '';
$kategori_options = wg_get_categories($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $harga = max(0, (int)($_POST['harga'] ?? 0));
    $stok = max(0, (int)($_POST['stok'] ?? 0));
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $link_gambar = trim($_POST['link_gambar'] ?? '');
    $nama_file_gambar = '';

    $kategori_valid = false;
    foreach ($kategori_options as $kat) {
        if ($kat['nama_kategori'] === $kategori) {
            $kategori_valid = true;
            break;
        }
    }
    if ($nama === '' || $kategori === '') {
        $pesan_error = 'Nama produk dan kategori wajib diisi.';
    } elseif (!$kategori_valid) {
        $pesan_error = 'Kategori produk tidak valid.';
    }

    if (empty($pesan_error) && isset($_FILES['file_gambar']) && $_FILES['file_gambar']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES['file_gambar']['error'] !== UPLOAD_ERR_OK) {
            $pesan_error = 'Upload gambar gagal. Silakan coba lagi.';
        } else {
            $nama_asli = $_FILES['file_gambar']['name'];
            $tmp_file = $_FILES['file_gambar']['tmp_name'];
            $ekstensi = strtolower(pathinfo($nama_asli, PATHINFO_EXTENSION));
            $ekstensi_boleh = ['jpg', 'jpeg', 'png', 'webp'];
            if (!in_array($ekstensi, $ekstensi_boleh, true)) {
                $pesan_error = 'Ekstensi file gambar harus JPG, JPEG, PNG, atau WEBP.';
            } elseif (@getimagesize($tmp_file) === false) {
                $pesan_error = 'File yang dipilih bukan gambar yang valid.';
            } else {
                $folder_tujuan = '../assets/img/';
                if (!is_dir($folder_tujuan)) mkdir($folder_tujuan, 0755, true);
                $nama_file_gambar = 'prod_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $ekstensi;
                if (!move_uploaded_file($tmp_file, $folder_tujuan . $nama_file_gambar)) {
                    $pesan_error = 'Gambar tidak dapat disimpan ke folder assets/img.';
                    $nama_file_gambar = '';
                }
            }
        }
    }

    if (empty($pesan_error) && $nama_file_gambar === '' && $link_gambar !== '') {
        if (!filter_var($link_gambar, FILTER_VALIDATE_URL)) {
            $pesan_error = 'Link gambar harus berupa URL yang valid.';
        } else {
            $nama_file_gambar = $link_gambar;
        }
    }

    if (empty($pesan_error)) {
        $nama_sql = mysqli_real_escape_string($conn, $nama);
        $desk_sql = mysqli_real_escape_string($conn, $deskripsi);
        $kat_sql = mysqli_real_escape_string($conn, $kategori);
        $img_sql = mysqli_real_escape_string($conn, $nama_file_gambar);
        $query = "INSERT INTO tb_produk (nama, harga, stok, deskripsi, poto, kategori) VALUES ('$nama_sql', $harga, $stok, '$desk_sql', '$img_sql', '$kat_sql')";
        if (mysqli_query($conn, $query)) {
            $pesan_sukses = 'Produk berhasil ditambahkan.';
            header('Refresh: 1; URL=produk.php');
        } else {
            if ($nama_file_gambar !== '' && !filter_var($nama_file_gambar, FILTER_VALIDATE_URL)) {
                @unlink('../assets/img/' . $nama_file_gambar);
            }
            $pesan_error = 'Gagal menyimpan produk ke database.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk - Wargt25 Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body class="bg-light">
<div id="wg-preloader"><div class="text-center"><div class="wg-loader-mark">Wargt<span>25</span></div><div class="wg-loader-bar"></div></div></div>
<nav class="navbar navbar-expand-lg navbar-dark shadow-sm navbar-wargt admin-nav">
    <div class="container">
        <div class="d-flex align-items-center gap-2">
            <a class="navbar-brand fw-bold font-display m-0" href="index.php">Wargt25 <span style="color:#a67c52;">Admin</span></a>
            <a href="../index.php" target="_blank" class="btn btn-sm rounded-pill px-3 fw-semibold" style="background-color: rgba(255,255,255,0.12); color:#fff; border:1px solid rgba(255,255,255,0.35);"><i class="bi bi-eye me-1"></i> Lihat Sebagai Pelanggan</a>
        </div>
        <a href="produk.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Kembali ke Produk</a>
    </div>
</nav>

<div class="container my-5" style="max-width: 650px;">
    <div class="card admin-card border-0 shadow-sm rounded-4 p-4 bg-white">
        <h5 class="font-display fw-bold mb-1" style="color:#2b302a;">Tambah Produk Baru</h5>
        <p class="text-muted small mb-4">Tambahkan menu kuliner lengkap dengan gambar lokal atau URL.</p>
        <?php if ($pesan_error): ?><div class="alert alert-danger py-2 small"><?= htmlspecialchars($pesan_error); ?></div><?php endif; ?>
        <?php if ($pesan_sukses): ?><div class="alert alert-success py-2 small"><?= htmlspecialchars($pesan_sukses); ?></div><?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="mb-3"><label class="form-label small fw-semibold">Nama Produk</label><input type="text" name="nama" class="form-control form-control-sm" required placeholder="Contoh: Baso Bakar Spesial" value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>"></div>
            <div class="row">
                <div class="col-md-6 mb-3"><label class="form-label small fw-semibold">Harga (Rp)</label><input type="number" min="0" name="harga" class="form-control form-control-sm" required value="<?= htmlspecialchars($_POST['harga'] ?? '') ?>"></div>
                <div class="col-md-6 mb-3"><label class="form-label small fw-semibold">Stok Awal</label><input type="number" min="0" name="stok" class="form-control form-control-sm" required value="<?= htmlspecialchars($_POST['stok'] ?? '') ?>"></div>
            </div>
            <div class="mb-3">
                <label class="form-label small fw-semibold">Kategori Menu</label>
                <select name="kategori" class="form-select form-select-sm" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($kategori_options as $kat): ?><option value="<?= htmlspecialchars($kat['nama_kategori']); ?>" <?= (($_POST['kategori'] ?? '') === $kat['nama_kategori']) ? 'selected' : ''; ?>><?= htmlspecialchars($kat['nama_kategori']); ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3"><label class="form-label small fw-semibold">Upload Gambar dari Komputer</label><input type="file" name="file_gambar" class="form-control form-control-sm" accept="image/jpeg,image/png,image/webp"><div class="form-text" style="font-size:.75rem;">JPG, PNG, atau WEBP.</div></div>
            <div class="mb-3"><label class="form-label small fw-semibold">Atau URL Gambar</label><input type="url" name="link_gambar" class="form-control form-control-sm" placeholder="https://example.com/gambar.jpg" value="<?= htmlspecialchars($_POST['link_gambar'] ?? '') ?>"></div>
            <div class="mb-4"><label class="form-label small fw-semibold">Deskripsi Singkat</label><textarea name="deskripsi" class="form-control form-control-sm" rows="3" placeholder="Deskripsi produk kuliner..."><?= htmlspecialchars($_POST['deskripsi'] ?? '') ?></textarea></div>
            <div class="d-flex justify-content-end gap-2"><a href="produk.php" class="btn btn-sm btn-light px-4 rounded-pill">Batal</a><button type="submit" class="btn btn-sm text-white px-4 rounded-pill" style="background:#273526;">Simpan Produk</button></div>
        </form>
    </div>
</div>
<button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/theme.js"></script>
</body>
</html>
