<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/database.php';

// Proteksi: hanya admin yang boleh mengakses halaman ini
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

if (!function_exists('rupiah')) {
    function rupiah($angka) {
        return "Rp " . number_format($angka, 0, ',', '.');
    }
}

// Deteksi apakah kolom status_pesanan sudah ada di tb_transaksi
$ada_status = false;
$cek_kolom = mysqli_query($conn, "SHOW COLUMNS FROM tb_transaksi");
if ($cek_kolom) {
    while ($k = mysqli_fetch_assoc($cek_kolom)) {
        if (strtolower($k['Field']) == 'status_pesanan') $ada_status = true;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Wargt25</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body class="bg-light">
<div id="wg-preloader">
    <div class="text-center">
        <div class="wg-loader-mark">Wargt<span>25</span></div>
        <div class="wg-loader-bar"></div>
    </div>
</div>

    <!-- NAVBAR ADMIN DENGAN MENU PRODUK -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm navbar-wargt admin-nav">
        <div class="container">
            <div class="d-flex align-items-center gap-2">
                <a class="navbar-brand fw-bold font-display m-0" href="index.php">Wargt25 <span style="color:#a67c52;">Admin</span></a>
                <a href="../index.php" target="_blank" class="btn btn-sm rounded-pill px-3 fw-semibold" style="background-color: rgba(255,255,255,0.12); color:#fff; border:1px solid rgba(255,255,255,0.35);" title="Buka tampilan yang dilihat pelanggan di tab baru">
                    <i class="bi bi-eye me-1"></i> Lihat Sebagai Pelanggan
                </a>
            </div>
            <div class="d-flex align-items-center gap-2">
                <!-- Tombol Navigasi Produk -->
                <a href="produk.php" class="btn btn-sm btn-outline-light rounded-pill px-3 fw-semibold">
                    <i class="bi bi-box-seam me-1"></i> Kelola Produk
                </a>
                <a href="../auth/logout.php" class="btn btn-sm px-3 rounded-pill text-white fw-semibold" style="background-color: #a67c52; font-size: 0.8rem; border: none;">
                    <i class="bi bi-arrow-left-right me-1"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- KONTEN UTAMA -->
    <div class="container my-5">
        <div class="card admin-card border-0 shadow-sm rounded-4 p-4 bg-white" style="border: 1px solid #e5e5ea !important;">
            <h5 class="font-display fw-bold mb-1" style="color: #2b302a;">Manajemen Pesanan Masuk</h5>
            <p class="text-muted small mb-4">Daftar pesanan dari pelanggan jauh / online yang masuk ke sistem.</p>

            <div class="table-responsive">
                <table class="table align-middle" style="color: #2b302a;">
                    <thead class="table-light" style="--bs-table-bg: #fcfaf6;">
                        <tr>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">ID Trx</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Jumlah Item</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Waktu Pesan</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Total Bayar</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Status</th>
                            <th class="text-center" style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Aksi Operasional</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // tb_transaksi: id_transaksi, id_pelanggan, tanggal, total_harga (+ status_pesanan opsional)
                        $query_orders = mysqli_query($conn, "SELECT * FROM tb_transaksi ORDER BY id_transaksi DESC");

                        if (!$query_orders || mysqli_num_rows($query_orders) == 0) {
                            echo '<tr><td colspan="6" class="text-center text-muted py-4">Belum ada pesanan online masuk.</td></tr>';
                        } else {
                            while ($row = mysqli_fetch_assoc($query_orders)):
                                $id_trx = $row['id_transaksi'];
                                $total = $row['total_harga'] ?? 0;
                                $status = $ada_status ? ($row['status_pesanan'] ?? 'Menunggu Pembayaran') : 'Menunggu Pembayaran';

                                $jumlah_item = 0;
                                $q_item = mysqli_query($conn, "SELECT SUM(jumlah) as total_item FROM tb_detail WHERE id_transaksi = $id_trx");
                                if ($q_item) {
                                    $r_item = mysqli_fetch_assoc($q_item);
                                    $jumlah_item = $r_item['total_item'] ?? 0;
                                }
                        ?>
                        <tr>
                            <td><b style="color: #a67c52;">#<?= $id_trx; ?></b></td>
                            <td class="fw-semibold"><?= (int)$jumlah_item; ?> item</td>
                            <td class="text-muted" style="font-size: 0.85rem;"><?= date('d M Y', strtotime($row['tanggal'])); ?></td>
                            <td class="fw-bold"><?= rupiah($total); ?></td>
                            <td>
                                <span class="badge rounded-pill px-2.5 py-1.5 small" style="background-color: rgba(166, 124, 82, 0.1); color: #a67c52; border: 1px solid rgba(166, 124, 82, 0.2); font-weight: 600;">
                                    <?= htmlspecialchars($status); ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <div class="d-flex justify-content-center gap-1">
                                    <a href="../cetak_nota.php?id=<?= $id_trx; ?>" target="_blank" class="btn btn-sm text-white px-3 rounded-pill" style="background-color: #273526; font-size: 0.8rem; font-weight: 600; border: none;">
                                        <i class="bi bi-printer me-1"></i> Cetak Struk
                                    </a>
                                    <a href="transaksi.php" class="btn btn-sm px-3 rounded-pill" style="background-color: transparent; color: #273526; border: 1px solid #273526; font-size: 0.8rem; font-weight: 600; text-decoration: none;">
                                        Ubah Status
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php
                            endwhile;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/theme.js"></script>
</body>
</html>
