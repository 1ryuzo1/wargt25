<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/database.php';

// Proteksi: hanya admin yang boleh mengakses halaman ini
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$id = intval($_GET['id'] ?? 0);
if ($id) {
    mysqli_query($conn, "DELETE FROM tb_produk WHERE id = $id");
}

header("Location: produk.php");
exit;
