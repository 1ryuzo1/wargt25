<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') { header("Location: ../auth/login.php"); exit; }
include_once '../config/database.php';

if (!function_exists('tgl_indo')) {
    function tgl_indo($tanggal) {
        if (empty($tanggal)) return '-';
        $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
        $ts = strtotime($tanggal);
        if (!$ts) return '-';
        return date('d', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
    }
}

// Cek apakah tb_user punya kolom created_at (opsional, tergantung setup DB)
$ada_created_at = false;
$cek_kolom = mysqli_query($conn, "SHOW COLUMNS FROM tb_user");
if ($cek_kolom) {
    while ($k = mysqli_fetch_assoc($cek_kolom)) {
        if (strtolower($k['Field']) == 'created_at') $ada_created_at = true;
    }
}

// Reset Password (Default Jadi: password123)
if (isset($_GET['reset'])) {
    $id = intval($_GET['reset']);
    $new_pass = password_hash('password123', PASSWORD_DEFAULT);
    mysqli_query($conn, "UPDATE tb_user SET password='$new_pass' WHERE id='$id'");
    header("Location: pelanggan.php"); exit;
}

// Hapus Pelanggan
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM tb_user WHERE id='$id' AND role='pelanggan'");
    header("Location: pelanggan.php"); exit;
}

$urutan = $ada_created_at ? "ORDER BY created_at DESC" : "ORDER BY id DESC";
$pelanggan_list = mysqli_query($conn, "SELECT * FROM tb_user WHERE role='pelanggan' $urutan");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Data Pelanggan - Wargt25 Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body class="bg-light">
<div id="wg-preloader">
    <div class="text-center">
        <div class="wg-loader-mark">Wargt<span>25</span></div>
        <div class="wg-loader-bar"></div>
    </div>
</div>

<div class="admin-wrapper">
    <nav id="sidebar" class="sidebar-wargt">
        <div class="sidebar-header p-4 border-bottom border-secondary">
            <h5 class="m-0 font-display fw-bold text-white">Wargt<span style="color:#a67c52;">25</span> <span class="text-white-50 fs-6 fw-normal">Admin</span></h5>
        </div>
        <ul class="list-unstyled components nav flex-column">
            <li class="nav-item"><a href="index.php" class="nav-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
            <li class="nav-item"><a href="produk.php" class="nav-link"><i class="bi bi-box-seam me-2"></i> Produk</a></li>
            <li class="nav-item"><a href="kategori.php" class="nav-link"><i class="bi bi-tags me-2"></i> Kategori</a></li>
            <li class="nav-item"><a href="transaksi.php" class="nav-link"><i class="bi bi-currency-dollar me-2"></i> Transaksi</a></li>
            <li class="nav-item"><a href="pelanggan.php" class="nav-link active"><i class="bi bi-people me-2"></i> Pelanggan</a></li>
            <li class="nav-item"><a href="../index.php" target="_blank" class="nav-link"><i class="bi bi-eye me-2"></i> Lihat Sebagai Pelanggan</a></li>
            <li class="nav-item"><a href="../auth/logout.php" class="nav-link text-danger"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
        </ul>
    </nav>

    <div id="content" class="p-5 w-100">
        <h3 class="font-display fw-bold text-dark mb-4">Manajemen Data Konsumen Terdaftar</h3>
        <div class="card admin-card border-0 shadow-sm p-4 rounded-4 bg-white">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Nama Lengkap</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>No. WhatsApp</th>
                            <?php if ($ada_created_at): ?><th>Tanggal Join</th><?php endif; ?>
                            <th>Aksi Operasi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$pelanggan_list || mysqli_num_rows($pelanggan_list) == 0): ?>
                            <tr><td colspan="6" class="text-center text-muted py-4">Belum ada pelanggan terdaftar.</td></tr>
                        <?php else: while ($u = mysqli_fetch_assoc($pelanggan_list)): ?>
                        <tr>
                            <td class="fw-bold text-dark"><?= htmlspecialchars($u['nama']); ?></td>
                            <td><code><?= htmlspecialchars($u['username']); ?></code></td>
                            <td><?= htmlspecialchars($u['email']); ?></td>
                            <td><?= $u['hp'] ? htmlspecialchars($u['hp']) : '-'; ?></td>
                            <?php if ($ada_created_at): ?><td><small class="text-muted"><?= tgl_indo($u['created_at']); ?></small></td><?php endif; ?>
                            <td>
                                <a href="pelanggan.php?reset=<?= $u['id']; ?>" class="btn btn-sm btn-warning px-3 rounded-pill me-1 text-dark fw-bold" onclick="return confirm('Reset password akun ini menjadi: password123?')"><i class="bi bi-shield-lock"></i> Reset</a>
                                <a href="pelanggan.php?delete=<?= $u['id']; ?>" class="btn btn-sm btn-outline-danger px-3 rounded-pill" onclick="return confirm('Hapus permanen akun pelanggan ini?')"><i class="bi bi-trash"></i></a>
                            </td>
                        </tr>
                        <?php endwhile; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/theme.js"></script>
</body>
</html>
