<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') { header("Location: ../auth/login.php"); exit; }
include_once '../config/database.php';

if (!function_exists('rupiah')) {
    function rupiah($angka) {
        return "Rp " . number_format($angka, 0, ',', '.');
    }
}
if (!function_exists('tgl_indo')) {
    function tgl_indo($tanggal) {
        if (empty($tanggal)) return '-';
        $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
        $ts = strtotime($tanggal);
        if (!$ts) return '-';
        return date('d', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
    }
}

// Cek apakah tb_transaksi punya kolom status_pesanan (opsional, tergantung setup DB)
$ada_status = false;
$cek_kolom = mysqli_query($conn, "SHOW COLUMNS FROM tb_transaksi");
if ($cek_kolom) {
    while ($k = mysqli_fetch_assoc($cek_kolom)) {
        if (strtolower($k['Field']) == 'status_pesanan') $ada_status = true;
    }
}

// Aksi Update Status Pesanan
if (isset($_POST['update_status']) && $ada_status) {
    $id_tx = intval($_POST['id_transaksi']);
    $allowed_status = ['Menunggu Pembayaran', 'Diproses', 'Dikirim', 'Selesai'];
    $status_raw = $_POST['status_pesanan'] ?? '';
    $status = in_array($status_raw, $allowed_status, true) ? $status_raw : 'Menunggu Pembayaran';
    $status = mysqli_real_escape_string($conn, $status);
    mysqli_query($conn, "UPDATE tb_transaksi SET status_pesanan='$status' WHERE id_transaksi='$id_tx'");
    header("Location: transaksi.php"); exit;
}

// tb_transaksi(id_transaksi, id_pelanggan, tanggal, total_harga, [status_pesanan])
// tb_user(id, nama, ...)
$transaksi_list = mysqli_query($conn, "SELECT t.*, u.nama FROM tb_transaksi t JOIN tb_user u ON t.id_pelanggan = u.id ORDER BY t.tanggal DESC, t.id_transaksi DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Transaksi - Wargt25 Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body class="bg-light">
<div id="wg-preloader">
    <div class="text-center">
        <div class="wg-loader-mark">Wargt<span>25</span></div>
        <div class="wg-loader-bar"></div>
    </div>
</div>

<div class="admin-wrapper">
    <nav id="sidebar" class="sidebar-wargt">
        <div class="sidebar-header p-4 border-bottom border-secondary">
            <h5 class="m-0 font-display fw-bold text-white">Wargt<span style="color:#a67c52;">25</span> <span class="text-white-50 fs-6 fw-normal">Admin</span></h5>
        </div>
        <ul class="list-unstyled components nav flex-column">
            <li class="nav-item"><a href="index.php" class="nav-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li>
            <li class="nav-item"><a href="produk.php" class="nav-link"><i class="bi bi-box-seam me-2"></i> Produk</a></li>
            <li class="nav-item"><a href="kategori.php" class="nav-link"><i class="bi bi-tags me-2"></i> Kategori</a></li>
            <li class="nav-item"><a href="transaksi.php" class="nav-link active"><i class="bi bi-currency-dollar me-2"></i> Transaksi</a></li>
            <li class="nav-item"><a href="pelanggan.php" class="nav-link"><i class="bi bi-people me-2"></i> Pelanggan</a></li>
            <li class="nav-item"><a href="../index.php" target="_blank" class="nav-link"><i class="bi bi-eye me-2"></i> Lihat Sebagai Pelanggan</a></li>
            <li class="nav-item"><a href="../auth/logout.php" class="nav-link text-danger"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
        </ul>
    </nav>

    <div id="content" class="p-5 w-100">
        <h3 class="font-display fw-bold text-dark mb-4">Daftar Transaksi Masuk</h3>

        <?php if (!$ada_status): ?>
            <div class="alert alert-warning small">
                Kolom <code>status_pesanan</code> belum ada di tabel <code>tb_transaksi</code>, jadi status pesanan belum bisa diubah dari sini.
                Tambahkan kolomnya (lihat <code>schema.sql</code>) untuk mengaktifkan fitur ini.
            </div>
        <?php endif; ?>

        <div class="card admin-card border-0 shadow-sm p-4 rounded-4 bg-white">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Nota</th>
                            <th>Pelanggan</th>
                            <th>Tanggal</th>
                            <th>Total Bayar</th>
                            <th>Status</th>
                            <?php if ($ada_status): ?><th>Ubah Status</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!$transaksi_list || mysqli_num_rows($transaksi_list) == 0): ?>
                            <tr><td colspan="6" class="text-center text-muted py-4">Belum ada transaksi masuk.</td></tr>
                        <?php else: while ($tx = mysqli_fetch_assoc($transaksi_list)): ?>
                        <tr>
                            <td class="fw-bold">#TRX-<?= $tx['id_transaksi']; ?></td>
                            <td><?= htmlspecialchars($tx['nama']); ?></td>
                            <td><small><?= tgl_indo($tx['tanggal']); ?></small></td>
                            <td class="fw-bold text-danger"><?= rupiah($tx['total_harga']); ?></td>
                            <td>
                                <span class="badge bg-secondary rounded-pill"><?= htmlspecialchars($ada_status ? ($tx['status_pesanan'] ?? 'Menunggu Pembayaran') : 'Menunggu Pembayaran'); ?></span>
                            </td>
                            <?php if ($ada_status): ?>
                            <td>
                                <form method="POST" action="" class="d-flex gap-2">
                                    <input type="hidden" name="id_transaksi" value="<?= $tx['id_transaksi']; ?>">
                                    <select name="status_pesanan" class="form-select form-select-sm" onchange="this.form.submit()">
                                        <option value="Menunggu Pembayaran" <?= $tx['status_pesanan'] == 'Menunggu Pembayaran' ? 'selected' : ''; ?>>Menunggu</option>
                                        <option value="Diproses" <?= $tx['status_pesanan'] == 'Diproses' ? 'selected' : ''; ?>>Diproses</option>
                                        <option value="Dikirim" <?= $tx['status_pesanan'] == 'Dikirim' ? 'selected' : ''; ?>>Dikirim</option>
                                        <option value="Selesai" <?= $tx['status_pesanan'] == 'Selesai' ? 'selected' : ''; ?>>Selesai</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endwhile; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/theme.js"></script>
</body>
</html>
