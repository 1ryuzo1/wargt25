<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') { header('Location: ../auth/login.php'); exit; }
include_once '../config/database.php';
include_once '../config/helpers.php';

wg_ensure_category_table($conn);
$pesan = '';
$jenis_pesan = 'success';

if (isset($_POST['add_kategori'])) {
    $nama = trim($_POST['nama_kategori'] ?? '');
    if ($nama === '') {
        $pesan = 'Nama kategori wajib diisi.';
        $jenis_pesan = 'danger';
    } else {
        $esc = mysqli_real_escape_string($conn, $nama);
        $slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $nama), '-'));
        $slugEsc = mysqli_real_escape_string($conn, $slug);
        $cek = mysqli_query($conn, "SELECT id_kategori FROM kategori WHERE nama_kategori='$esc' LIMIT 1");
        if ($cek && mysqli_num_rows($cek) > 0) {
            $pesan = 'Kategori tersebut sudah ada.';
            $jenis_pesan = 'warning';
        } elseif (mysqli_query($conn, "INSERT INTO kategori (nama_kategori, slug) VALUES ('$esc', '$slugEsc')")) {
            $pesan = 'Kategori berhasil ditambahkan.';
        } else {
            $pesan = 'Kategori gagal ditambahkan.';
            $jenis_pesan = 'danger';
        }
    }
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $kat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama_kategori FROM kategori WHERE id_kategori=$id LIMIT 1"));
    if (!$kat) {
        $pesan = 'Kategori tidak ditemukan.';
        $jenis_pesan = 'danger';
    } else {
        $escKat = mysqli_real_escape_string($conn, $kat['nama_kategori']);
        $usedRow = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM tb_produk WHERE kategori='$escKat'"));
        if ((int)($usedRow['n'] ?? 0) > 0) {
            $pesan = 'Kategori masih dipakai produk, jadi tidak dihapus.';
            $jenis_pesan = 'warning';
        } elseif (mysqli_query($conn, "DELETE FROM kategori WHERE id_kategori=$id")) {
            $pesan = 'Kategori berhasil dihapus.';
        } else {
            $pesan = 'Kategori gagal dihapus.';
            $jenis_pesan = 'danger';
        }
    }
}

$kategori_list = mysqli_query($conn, "SELECT * FROM kategori ORDER BY id_kategori ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Kategori - Wargt25 Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body class="bg-light">
<div id="wg-preloader"><div class="text-center"><div class="wg-loader-mark">Wargt<span>25</span></div><div class="wg-loader-bar"></div></div></div>
<div class="admin-wrapper">
<nav id="sidebar" class="sidebar-wargt"><div class="sidebar-header p-4 border-bottom border-secondary"><h5 class="m-0 font-display fw-bold text-white">Wargt<span style="color:#a67c52;">25</span> <span class="text-white-50 fs-6 fw-normal">Admin</span></h5></div><ul class="list-unstyled components nav flex-column">
<li class="nav-item"><a href="index.php" class="nav-link"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a></li><li class="nav-item"><a href="produk.php" class="nav-link"><i class="bi bi-box-seam me-2"></i> Produk</a></li><li class="nav-item"><a href="kategori.php" class="nav-link active"><i class="bi bi-tags me-2"></i> Kategori</a></li><li class="nav-item"><a href="transaksi.php" class="nav-link"><i class="bi bi-receipt me-2"></i> Transaksi</a></li><li class="nav-item"><a href="pelanggan.php" class="nav-link"><i class="bi bi-people me-2"></i> Pelanggan</a></li><li class="nav-item"><a href="../index.php" target="_blank" class="nav-link"><i class="bi bi-eye me-2"></i> Lihat Sebagai Pelanggan</a></li><li class="nav-item"><a href="../auth/logout.php" class="nav-link text-danger"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
</ul></nav>
<div id="content" class="p-4 p-lg-5 w-100"><div class="row g-4">
<div class="col-md-4"><div class="card admin-card border-0 p-4 shadow-sm rounded-4 bg-white"><h5 class="font-display fw-bold mb-3 text-dark">Tambah Kategori Baru</h5>
<?php if($pesan): ?><div class="alert alert-<?= $jenis_pesan ?> py-2 small"><?= htmlspecialchars($pesan) ?></div><?php endif; ?>
<form method="POST"><div class="mb-3"><label class="form-label">Nama Kategori</label><input type="text" name="nama_kategori" class="form-control" required placeholder="Contoh: Paket Hemat"></div><button type="submit" name="add_kategori" class="btn w-100 rounded-pill text-white fw-semibold" style="background:#273526;">Simpan Kategori</button></form>
</div></div>
<div class="col-md-8"><div class="card admin-card border-0 p-4 shadow-sm rounded-4 bg-white"><h5 class="font-display fw-bold mb-3 text-dark">Daftar Kategori Produk</h5><div class="table-responsive"><table class="table table-hover align-middle"><thead class="table-dark"><tr><th>ID</th><th>Nama Kategori</th><th>Slug</th><th>Aksi</th></tr></thead><tbody>
<?php if(!$kategori_list || mysqli_num_rows($kategori_list)===0): ?><tr><td colspan="4" class="text-center text-muted py-4">Belum ada kategori.</td></tr><?php else: while($k=mysqli_fetch_assoc($kategori_list)): ?><tr><td><?= (int)$k['id_kategori']; ?></td><td class="fw-bold text-dark"><?= htmlspecialchars($k['nama_kategori']); ?></td><td><code>/kategori/<?= htmlspecialchars($k['slug']); ?></code></td><td><a href="kategori.php?delete=<?= (int)$k['id_kategori']; ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3" onclick="return confirm('Hapus kategori ini?')"><i class="bi bi-trash"></i></a></td></tr><?php endwhile; endif; ?>
</tbody></table></div></div></div>
</div></div></div>
<button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script><script src="../assets/js/theme.js"></script>
</body></html>
