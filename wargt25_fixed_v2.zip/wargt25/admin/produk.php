<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once '../config/database.php';

// Proteksi: hanya admin yang boleh mengakses halaman ini
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Fungsi format rupiah
if (!function_exists('rupiah')) {
    function rupiah($angka) {
        return "Rp " . number_format($angka, 0, ',', '.');
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Produk - Wargt25 Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/theme.css">
</head>
<body class="bg-light">
<div id="wg-preloader">
    <div class="text-center">
        <div class="wg-loader-mark">Wargt<span>25</span></div>
        <div class="wg-loader-bar"></div>
    </div>
</div>

    <!-- NAVBAR ADMIN -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm navbar-wargt admin-nav">
        <div class="container">
            <div class="d-flex align-items-center gap-2">
                <a class="navbar-brand fw-bold font-display m-0" href="index.php">Wargt25 <span style="color:#a67c52;">Admin</span></a>
                <a href="../index.php" target="_blank" class="btn btn-sm rounded-pill px-3 fw-semibold" style="background-color: rgba(255,255,255,0.12); color:#fff; border:1px solid rgba(255,255,255,0.35);" title="Buka tampilan yang dilihat pelanggan di tab baru">
                    <i class="bi bi-eye me-1"></i> Lihat Sebagai Pelanggan
                </a>
            </div>
            <div class="d-flex align-items-center gap-2">
                <a href="index.php" class="btn btn-sm btn-outline-light rounded-pill px-3">Dashboard Pesanan</a>
                <a href="../auth/logout.php" class="btn btn-sm px-3 rounded-pill text-white fw-semibold" style="background-color: #a67c52; font-size: 0.8rem; border: none;">
                    <i class="bi bi-arrow-left-right me-1"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- KONTEN UTAMA -->
    <div class="container my-5">
        <div class="card admin-card border-0 shadow-sm rounded-4 p-4 bg-white" style="border: 1px solid #e5e5ea !important;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h5 class="font-display fw-bold mb-1" style="color: #2b302a;">Manajemen Produk Kuliner</h5>
                    <p class="text-muted small mb-0">Kelola menu, harga, kategori, dan stok produk Wargt25.</p>
                </div>
                <!-- Tombol Tambah Produk -->
                <a href="tambah_produk.php" class="btn btn-sm text-white px-3 rounded-pill fw-semibold" style="background-color: #273526;">
                    <i class="bi bi-plus-lg me-1"></i> Tambah Produk Baru
                </a>
            </div>

            <div class="table-responsive">
                <table class="table align-middle" style="color: #2b302a;">
                    <thead class="table-light" style="--bs-table-bg: #fcfaf6;">
                        <tr>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">No</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Nama Produk</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Kategori</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Harga</th>
                            <th style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Stok</th>
                            <th class="text-center" style="color: #5c5e5a; font-size: 0.85rem; font-weight: 600;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Tabel & kolom tb_produk: id, nama, harga, stok, deskripsi, poto, kategori
                        $query_produk = mysqli_query($conn, "SELECT * FROM tb_produk ORDER BY id DESC");

                        if (!$query_produk || mysqli_num_rows($query_produk) == 0) {
                            echo '<tr><td colspan="6" class="text-center text-muted py-4">Belum ada data produk tersedia.</td></tr>';
                        } else {
                            $no = 1;
                            while ($row = mysqli_fetch_assoc($query_produk)):
                        ?>
                        <tr>
                            <td class="text-muted"><?= $no++; ?></td>
                            <td class="fw-semibold"><?= htmlspecialchars($row['nama']); ?></td>
                            <td>
                                <?php if (!empty($row['kategori'])): ?>
                                    <span class="badge rounded-pill px-2.5 py-1.5" style="background-color: rgba(166, 124, 82, 0.12); color: #a67c52; font-weight: 600;"><?= htmlspecialchars($row['kategori']); ?></span>
                                <?php else: ?>
                                    <span class="badge rounded-pill px-2.5 py-1.5 bg-danger-subtle text-danger">Belum diset</span>
                                <?php endif; ?>
                            </td>
                            <td class="fw-bold" style="color: #a67c52;"><?= rupiah($row['harga']); ?></td>
                            <td>
                                <span class="badge rounded-pill px-2.5 py-1.5" style="background-color: rgba(39, 53, 38, 0.1); color: #273526; font-weight: 600;">
                                    <?= $row['stok']; ?> Porsi/Item
                                </span>
                            </td>
                            <td class="text-center">
                                <div class="d-flex justify-content-center gap-1">
                                    <a href="edit_produk.php?id=<?= $row['id']; ?>" class="btn btn-sm px-3 rounded-pill" style="background-color: transparent; color: #a67c52; border: 1px solid #a67c52; font-size: 0.8rem; font-weight: 600;">
                                        <i class="bi bi-pencil me-1"></i> Edit
                                    </a>
                                    <a href="hapus_produk.php?id=<?= $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus produk ini?')" class="btn btn-sm px-3 rounded-pill text-white" style="background-color: #dc3545; font-size: 0.8rem; font-weight: 600;">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php
                            endwhile;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/theme.js"></script>
</body>
</html>
