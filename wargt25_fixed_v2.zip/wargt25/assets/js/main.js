// Legacy compatibility entry point. Wargt25 sekarang memakai theme.js sebagai
// interaksi utama; file ini tetap aman dipanggil dari halaman lama.
(function () {
  "use strict";
  function toTop() { window.scrollTo({ top: 0, behavior: "smooth" }); }
  function confirmDelete(url) {
    if (window.confirm("Apakah Anda yakin ingin menghapus data ini?")) window.location.href = url;
  }
  window.wgToTop = toTop;
  window.confirmDelete = confirmDelete;
})();
