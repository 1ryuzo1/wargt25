/* WARGT25 — shared interactions. */
(function () {
  "use strict";

  function init() {
    initPreloader();
    initNavbarShrink();
    initTiltCards();
    initRipple();
    initBackToTop();
    initRevealFallback();
    initCartBadge();
    initScrollProgress();
    initStatCounters();
    initFlipCardsTouch();
    initStarPicker();
  }

  function initPreloader() {
    var pre = document.getElementById("wg-preloader");
    if (!pre) return;
    var removed = false;
    var hide = function () {
      if (removed) return;
      removed = true;
      pre.classList.add("is-hidden");
      setTimeout(function () { if (pre && pre.parentNode) pre.remove(); }, 650);
    };
    // Jangan menunggu gambar/CDN eksternal. Konten lokal tetap bisa tampil.
    setTimeout(hide, document.readyState === "loading" ? 350 : 120);
    // Safety net tambahan kalau browser mengalami resource hang.
    setTimeout(hide, 1600);
  }

  function initNavbarShrink() {
    var nav = document.querySelector(".navbar-wargt");
    if (!nav) return;
    var onScroll = function () { nav.classList.toggle("is-scrolled", window.scrollY > 24); };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  function initTiltCards() {
    var cards = document.querySelectorAll(".tilt-card");
    if (!cards.length) return;
    var isCoarse = window.matchMedia && window.matchMedia("(pointer: coarse)").matches;
    if (isCoarse) return;
    cards.forEach(function (card) {
      var rect = null;
      card.addEventListener("mouseenter", function () { rect = card.getBoundingClientRect(); });
      card.addEventListener("mousemove", function (e) {
        if (!rect) rect = card.getBoundingClientRect();
        var px = (e.clientX - rect.left) / rect.width, py = (e.clientY - rect.top) / rect.height;
        card.style.setProperty("--rx", ((0.5 - py) * 8).toFixed(2) + "deg");
        card.style.setProperty("--ry", ((px - 0.5) * 10).toFixed(2) + "deg");
        card.style.setProperty("--ty", "-6px"); card.style.setProperty("--sc", "1.015");
        card.style.setProperty("--mx", (px * 100).toFixed(1) + "%"); card.style.setProperty("--my", (py * 100).toFixed(1) + "%");
      });
      card.addEventListener("mouseleave", function () {
        card.style.setProperty("--rx", "0deg"); card.style.setProperty("--ry", "0deg");
        card.style.setProperty("--ty", "0px"); card.style.setProperty("--sc", "1"); rect = null;
      });
    });
  }

  function initRipple() {
    document.addEventListener("click", function (e) {
      var btn = e.target.closest ? e.target.closest(".btn") : null;
      if (!btn) return;
      var circle = document.createElement("span"), rect = btn.getBoundingClientRect();
      var size = Math.max(rect.width, rect.height);
      circle.className = "wg-ripple";
      circle.style.width = circle.style.height = size + "px";
      circle.style.left = (e.clientX - rect.left - size / 2) + "px";
      circle.style.top = (e.clientY - rect.top - size / 2) + "px";
      btn.appendChild(circle);
      setTimeout(function () { if (circle.parentNode) circle.remove(); }, 650);
    });
  }

  function initBackToTop() {
    var btn = document.getElementById("wg-top");
    if (!btn) return;
    window.addEventListener("scroll", function () { btn.classList.toggle("is-visible", window.scrollY > 420); }, { passive: true });
    btn.addEventListener("click", function () { window.scrollTo({ top: 0, behavior: "smooth" }); });
  }

  function initRevealFallback() {
    var els = document.querySelectorAll("[data-reveal]");
    if (!els.length) return;
    if (!("IntersectionObserver" in window)) { els.forEach(function (el) { el.classList.add("is-visible"); }); return; }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) { if (entry.isIntersecting) { entry.target.classList.add("is-visible"); obs.unobserve(entry.target); } });
    }, { threshold: 0.15 });
    els.forEach(function (el) { obs.observe(el); });
  }

  function initCartBadge() {
    var badge = document.querySelector(".cart-badge");
    if (!badge) return;
    var count = parseInt(badge.textContent.trim(), 10) || 0;
    if (count > 0) badge.classList.add("has-items");
  }

  function initScrollProgress() {
    var bar = document.getElementById("wg-progress");
    if (!bar) return;
    var onScroll = function () {
      var h = document.documentElement, max = h.scrollHeight - h.clientHeight;
      bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + "%";
    };
    onScroll(); window.addEventListener("scroll", onScroll, { passive: true }); window.addEventListener("resize", onScroll);
  }

  function initStatCounters() {
    var nums = document.querySelectorAll(".wg-stat-num[data-count]");
    if (!nums.length) return;
    var animate = function (el) {
      var target = parseFloat(el.getAttribute("data-count")) || 0;
      var decimals = parseInt(el.getAttribute("data-decimals"), 10) || 0;
      var suffix = el.getAttribute("data-suffix") || "", duration = 900, start = null;
      var step = function (ts) {
        if (!start) start = ts;
        var progress = Math.min((ts - start) / duration, 1), eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = (target * eased).toFixed(decimals) + suffix;
        if (progress < 1) requestAnimationFrame(step); else el.textContent = target.toFixed(decimals) + suffix;
      };
      requestAnimationFrame(step);
    };
    if (!("IntersectionObserver" in window)) { nums.forEach(animate); return; }
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) { if (entry.isIntersecting) { animate(entry.target); obs.unobserve(entry.target); } });
    }, { threshold: 0.4 });
    nums.forEach(function (el) { obs.observe(el); });
  }

  function initFlipCardsTouch() {
    var cards = document.querySelectorAll(".wg-menu-card-wrap"), isCoarse = window.matchMedia && window.matchMedia("(pointer: coarse)").matches;
    if (!cards.length || !isCoarse) return;
    cards.forEach(function (wrap) {
      wrap.addEventListener("click", function (e) {
        if (e.target.closest("a, button, input, select, textarea, form")) return;
        wrap.classList.toggle("is-flipped");
      });
    });
  }

  function initStarPicker() {
    document.querySelectorAll(".wg-star-picker").forEach(function (picker) {
      var target = picker.getAttribute("data-target"), hidden = target ? document.querySelector(target) : null;
      var stars = picker.querySelectorAll("i");
      var setValue = function (val) {
        val = Math.max(1, Math.min(5, parseInt(val, 10) || 5));
        stars.forEach(function (star, i) { star.classList.toggle("is-active", i < val); });
        if (hidden) hidden.value = val;
      };
      setValue(hidden ? hidden.value : 5);
      stars.forEach(function (star, i) { star.addEventListener("mouseenter", function () { setValue(i + 1); }); star.addEventListener("click", function () { if (hidden) hidden.value = i + 1; setValue(i + 1); }); });
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
  else init();
})();
