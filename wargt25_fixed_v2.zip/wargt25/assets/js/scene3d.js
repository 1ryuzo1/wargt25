/* =========================================================================
   WARGT25 — INTERACTIVE 3D SCENE
   Procedurally-built dinnerware (plate, sate skewer, fork, spoon, chili)
   rendered with Three.js. Drag with mouse/touch to orbit; auto-rotates
   gently when idle. No external model files required.
   ========================================================================= */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", boot);

  function boot() {
    var panel = document.getElementById("wg3d-panel");
    if (!panel) return;

    var loadingEl = document.getElementById("wg3d-loading");
    var width = panel.clientWidth || 340;
    var height = panel.clientHeight || 380;

    function finishLoading(message) {
      if (!loadingEl) return;
      loadingEl.innerHTML = '<div class="text-center"><i class="bi bi-box-seam fs-3 d-block mb-2"></i><div>' + message + '</div></div>';
      loadingEl.classList.add("wg-3d-fallback");
      setTimeout(function () { if (loadingEl && loadingEl.parentNode) loadingEl.remove(); }, 1400);
    }

    if (typeof THREE === "undefined") {
      finishLoading("Mode 3D sedang tidak tersedia.");
      return;
    }
    if (typeof THREE.OrbitControls === "undefined") {
      finishLoading("Kontrol 3D tidak tersedia.");
      return;
    }

    /* ---------------- Scene / Camera / Renderer ---------------- */
    var scene = new THREE.Scene();

    var camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 2.3, 4.6);

    var renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch (e) {
      finishLoading("Model 3D tidak didukung di perangkat ini.");
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = true;
    panel.insertBefore(renderer.domElement, panel.firstChild);

    /* ---------------- Lighting ---------------- */
    var ambient = new THREE.AmbientLight(0xfff2e0, 0.65);
    scene.add(ambient);

    var keyLight = new THREE.DirectionalLight(0xfff6ea, 1.05);
    keyLight.position.set(3, 5, 4);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    scene.add(keyLight);

    var warmFill = new THREE.PointLight(0xa67c52, 0.9, 12);
    warmFill.position.set(-3, 1.5, 2);
    scene.add(warmFill);

    var rimLight = new THREE.DirectionalLight(0x8fae7d, 0.35);
    rimLight.position.set(-2, 2, -3);
    scene.add(rimLight);

    /* ---------------- Group holding all dinnerware ---------------- */
    var group = new THREE.Group();
    scene.add(group);

    // Plate (two stacked cylinders for a rimmed-plate look)
    var plateMat = new THREE.MeshStandardMaterial({ color: 0xfffaf2, roughness: 0.35, metalness: 0.08 });
    var plateBase = new THREE.Mesh(new THREE.CylinderGeometry(1.55, 1.45, 0.12, 48), plateMat);
    plateBase.position.y = -0.35;
    plateBase.receiveShadow = true;
    group.add(plateBase);

    var plateInner = new THREE.Mesh(
      new THREE.CylinderGeometry(1.2, 1.15, 0.06, 48),
      new THREE.MeshStandardMaterial({ color: 0xf3ead9, roughness: 0.5, metalness: 0.02 })
    );
    plateInner.position.y = -0.26;
    plateInner.receiveShadow = true;
    group.add(plateInner);

    // Sate skewers (grilled skewer sticks with alternating chunks) — nod to "Bakar-bakaran"
    function buildSkewer(x, z, rotY, count) {
      var skGroup = new THREE.Group();
      var stick = new THREE.Mesh(
        new THREE.CylinderGeometry(0.02, 0.02, 1.7, 8),
        new THREE.MeshStandardMaterial({ color: 0xc9a276, roughness: 0.6 })
      );
      stick.rotation.z = Math.PI / 2;
      stick.castShadow = true;
      skGroup.add(stick);

      var meatColors = [0x8a4b32, 0xa5602f, 0x7a3f28];
      for (var i = 0; i < count; i++) {
        var geo = new THREE.BoxGeometry(0.24, 0.22, 0.24);
        var mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
          color: meatColors[i % meatColors.length], roughness: 0.75
        }));
        mesh.position.x = -0.55 + i * 0.37;
        mesh.rotation.y = Math.random() * 0.4;
        mesh.castShadow = true;
        skGroup.add(mesh);
      }
      skGroup.position.set(x, -0.12, z);
      skGroup.rotation.y = rotY;
      return skGroup;
    }

    group.add(buildSkewer(-0.1, 0.15, 0.18, 4));
    group.add(buildSkewer(0.05, -0.35, -0.35, 4));

    // Small chili garnish
    var chiliMat = new THREE.MeshStandardMaterial({ color: 0xc23b3b, roughness: 0.45 });
    var chili = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.42, 10), chiliMat);
    chili.rotation.z = Math.PI * 0.62;
    chili.position.set(0.95, -0.16, 0.85);
    chili.castShadow = true;
    group.add(chili);
    var chiliStem = new THREE.Mesh(
      new THREE.CylinderGeometry(0.015, 0.02, 0.08, 6),
      new THREE.MeshStandardMaterial({ color: 0x4c7a3a, roughness: 0.6 })
    );
    chiliStem.position.set(0.78, -0.1, 0.98);
    chiliStem.rotation.z = Math.PI * 0.62;
    group.add(chiliStem);

    // Fork (handle + 3 tines)
    var metalMat = new THREE.MeshStandardMaterial({ color: 0xdedede, roughness: 0.25, metalness: 0.85 });
    var fork = new THREE.Group();
    var forkHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, 1.5, 16), metalMat);
    forkHandle.castShadow = true;
    fork.add(forkHandle);
    var forkHead = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.32, 0.05), metalMat);
    forkHead.position.y = 0.86;
    forkHead.castShadow = true;
    fork.add(forkHead);
    for (var t = -1; t <= 1; t++) {
      var tine = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, 0.34, 8), metalMat);
      tine.position.set(t * 0.075, 1.14, 0);
      tine.castShadow = true;
      fork.add(tine);
    }
    fork.rotation.z = Math.PI * 0.44;
    fork.position.set(-1.55, -0.02, 0.55);
    group.add(fork);

    // Spoon (handle + bowl made from a scaled sphere)
    var spoon = new THREE.Group();
    var spoonHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, 1.45, 16), metalMat);
    spoonHandle.castShadow = true;
    spoon.add(spoonHandle);
    var spoonBowl = new THREE.Mesh(new THREE.SphereGeometry(0.19, 20, 16), metalMat);
    spoonBowl.scale.set(1, 0.55, 1.35);
    spoonBowl.position.y = 0.86;
    spoonBowl.castShadow = true;
    spoon.add(spoonBowl);
    spoon.rotation.z = -Math.PI * 0.44;
    spoon.position.set(1.55, -0.02, 0.55);
    group.add(spoon);

    // Steam wisps rising from the skewers (soft transparent torus-knot-free planes)
    var steamGroup = new THREE.Group();
    var steamMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.18, side: THREE.DoubleSide });
    for (var s = 0; s < 3; s++) {
      var plane = new THREE.Mesh(new THREE.PlaneGeometry(0.05, 0.5), steamMat.clone());
      plane.position.set(-0.3 + s * 0.3, 0.35, 0.1);
      steamGroup.add(plane);
    }
    group.add(steamGroup);

    group.rotation.x = -0.08;

    /* ---------------- Controls: drag to orbit ---------------- */
    var controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableZoom = false;
    controls.enablePan = false;
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 1.1;
    controls.minPolarAngle = Math.PI * 0.32;
    controls.maxPolarAngle = Math.PI * 0.58;
    controls.target.set(0, -0.1, 0);

    var idleTimer = null;
    controls.addEventListener("start", function () {
      controls.autoRotate = false;
      if (idleTimer) clearTimeout(idleTimer);
    });
    controls.addEventListener("end", function () {
      idleTimer = setTimeout(function () { controls.autoRotate = true; }, 2200);
    });

    /* ---------------- Resize handling ---------------- */
    function onResize() {
      var w = panel.clientWidth || width;
      var h = panel.clientHeight || height;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    }
    window.addEventListener("resize", onResize);

    /* ---------------- Render loop ---------------- */
    var clock = new THREE.Clock();
    var firstFrame = true;
    function animate() {
      requestAnimationFrame(animate);
      var t = clock.getElapsedTime();
      group.position.y = Math.sin(t * 0.9) * 0.04;
      steamGroup.children.forEach(function (p, i) {
        p.position.y = 0.35 + ((t * 0.4 + i * 0.3) % 1) * 0.6;
        p.material.opacity = 0.22 * (1 - ((t * 0.4 + i * 0.3) % 1));
      });
      controls.update();
      renderer.render(scene, camera);
      if (firstFrame) {
        firstFrame = false;
        if (loadingEl) loadingEl.style.opacity = "0";
        setTimeout(function () { if (loadingEl) loadingEl.remove(); }, 400);
      }
    }
    animate();
  }
})();
