<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once '../config/database.php';

if (isset($_POST['login'])) {
    $username_email = mysqli_real_escape_string($conn, $_POST['username_email']);
    $password = $_POST['password'];

    // Cari user berdasarkan username ataupun email
    $res = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$username_email' OR email='$username_email'");
    
    if ($res && mysqli_num_rows($res) === 1) {
        $row = mysqli_fetch_assoc($res);
        // Verifikasi kecocokan hash password bawaan database
        if (password_verify($password, $row['password'])) {
            $_SESSION['id_user']  = $row['id'];
            $_SESSION['nama']     = $row['nama'];
            $_SESSION['role']     = $row['role']; // admin / pelanggan

            if ($row['role'] == 'admin') {
                header("Location: ../admin/index.php"); // Masuk ke dashboard admin
            } else {
                header("Location: ../index.php"); // Pelanggan biasa ke depan
            }
            exit;
        }
    }
    $error = "Username/Email atau Password Anda keliru!";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - Wargt25</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/theme.css">
    <style>
        .btn-moss { background-color: #273526; color: white; border-radius: 50px; font-weight: 600; font-size: 0.9rem; border: none; }
        .btn-moss:hover { background-color: #384d37; color: white; }
    </style>
</head>
<body>
<div class="wg-auth-wrap">
    <div class="wg-auth-visual">
        <div class="wg-auth-visual-inner">
            <div class="font-display fw-semibold fs-3 mb-3">Wargt<span style="color:#c9a276;">25</span></div>
            <h2 class="font-display fw-semibold" style="line-height:1.25;">Kelezatan autentik, satu klik lagi dari mejamu.</h2>
            <p class="text-white-50 mt-3">Masuk untuk melacak pesanan, menyimpan alamat, dan menikmati pengalaman belanja kuliner yang lebih personal.</p>
            <div class="wg-trust mt-4">
                <span><i class="bi bi-patch-check-fill"></i> Bahan Segar Pilihan</span>
                <span><i class="bi bi-fire"></i> Resep Autentik</span>
            </div>
        </div>
    </div>
    <div class="wg-auth-form">
        <div class="wg-auth-card">
            <h4 class="font-display fw-bold mb-1 text-dark text-center">Selamat Datang Kembali</h4>
            <p class="text-muted text-center small mb-4">Masuk ke platform e-commerce kuliner premium</p>

            <?php if(isset($error)): ?>
                <div class="alert alert-danger py-2 small" role="alert"><?= $error ?></div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-semibold text-muted">Username atau Email</label>
                    <input type="text" name="username_email" class="form-control rounded-3 py-2 text-sm" placeholder="Masukkan akun Anda" required>
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-semibold text-muted">Password</label>
                    <input type="password" name="password" class="form-control rounded-3 py-2" placeholder="••••••••" required>
                </div>
                <button type="submit" name="login" class="btn btn-moss w-100 py-2.5 mb-3">Masuk Akun</button>
                <div class="text-center"><small class="text-muted">Belum punya akun? <a href="register.php" class="text-decoration-none fw-bold" style="color: #a67c52;">Daftar Sekarang</a></small></div>
            </form>
        </div>
    </div>
</div>
</body>
</html>