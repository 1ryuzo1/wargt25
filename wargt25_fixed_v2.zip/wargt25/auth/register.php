<?php
include_once '../config/database.php';

if (isset($_POST['register'])) {
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Proteksi password hash aman
    $hp       = mysqli_real_escape_string($conn, $_POST['hp']);
    $alamat   = mysqli_real_escape_string($conn, $_POST['alamat']);

    // Validasi duplikasi username agar tidak bentrok
    $cek = mysqli_query($conn, "SELECT id, username, email FROM tb_user WHERE username = '$username' OR email = '$email' LIMIT 1");
    if ($cek && mysqli_num_rows($cek) > 0) {
        $existing = mysqli_fetch_assoc($cek);
        $error = (strcasecmp($existing['username'] ?? '', $username) === 0)
            ? 'Username sudah terdaftar! Gunakan nama lain.'
            : 'Email sudah terdaftar! Gunakan email lain.';
    } else {
        $q = "INSERT INTO tb_user (nama, email, username, password, hp, alamat, role) VALUES ('$nama', '$email', '$username', '$password', '$hp', '$alamat', 'pelanggan')";
        if (mysqli_query($conn, $q)) {
            echo "<script>alert('Registrasi berhasil! Silakan masuk.'); window.location.href='login.php';</script>";
            exit;
        }
        $error = 'Registrasi gagal disimpan. Pastikan username dan email belum digunakan.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - Wargt25</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/theme.css">
    <style>
        .btn-moss { background-color: #273526; color: white; border-radius: 50px; font-weight: 600; border: none; }
        .btn-moss:hover { background-color: #384d37; color: white; }
        .wg-auth-form { padding: 40px 20px; }
    </style>
</head>
<body>
<div class="wg-auth-wrap">
    <div class="wg-auth-visual" style="background-image: linear-gradient(rgba(27,36,25,.55), rgba(27,36,25,.78)), url('https://images.unsplash.com/photo-1414235077428-338989a2e8c0?q=80&w=1200&auto=format&fit=crop');">
        <div class="wg-auth-visual-inner">
            <div class="font-display fw-semibold fs-3 mb-3">Wargt<span style="color:#c9a276;">25</span></div>
            <h2 class="font-display fw-semibold" style="line-height:1.25;">Bergabung dan nikmati kuliner favoritmu kapan saja.</h2>
            <p class="text-white-50 mt-3">Daftar sekali, pesan seterusnya — riwayat pesanan dan ulasan tersimpan rapi di akunmu.</p>
        </div>
    </div>
    <div class="wg-auth-form">
        <div class="wg-auth-card" style="max-width:460px;">
            <h5 class="font-display fw-bold mb-1 text-dark text-center">Bergabung dengan Wargt<span style="color:#a67c52;">25</span></h5>
            <p class="text-muted text-center small mb-4">Buat akun pelanggan untuk melakukan pemesanan kuliner</p>

            <?php if(isset($error)): ?>
                <div class="alert alert-danger py-2 small"><?= $error ?></div>
            <?php endif; ?>

            <form action="" method="POST">
                <div class="mb-2">
                    <label class="small fw-semibold text-muted mb-1">Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control rounded-3 form-control-sm" placeholder="Nama asli Anda" required>
                </div>
                <div class="mb-2">
                    <label class="small fw-semibold text-muted mb-1">Email Aktif</label>
                    <input type="email" name="email" class="form-control rounded-3 form-control-sm" placeholder="nama@email.com" required>
                </div>
                <div class="row g-2 mb-2">
                    <div class="col-6">
                        <label class="small fw-semibold text-muted mb-1">Username</label>
                        <input type="text" name="username" class="form-control rounded-3 form-control-sm" placeholder="ex: wargt_user" required>
                    </div>
                    <div class="col-6">
                        <label class="small fw-semibold text-muted mb-1">WhatsApp / HP</label>
                        <input type="text" name="hp" class="form-control rounded-3 form-control-sm" placeholder="08xxxxxx" required>
                    </div>
                </div>
                <div class="mb-2">
                    <label class="small fw-semibold text-muted mb-1">Password</label>
                    <input type="password" name="password" class="form-control rounded-3 form-control-sm" placeholder="••••••••" required>
                </div>
                <div class="mb-3">
                    <label class="small fw-semibold text-muted mb-1">Alamat Rumah Tinggal</label>
                    <textarea name="alamat" class="form-control rounded-3 form-control-sm" rows="2" placeholder="Nama jalan, nomor rumah, RT/RW..." required></textarea>
                </div>
                <button type="submit" name="register" class="btn btn-moss w-100 py-2 mb-2 btn-sm">Daftar Akun Baru</button>
                <div class="text-center"><small class="text-muted">Sudah punya akun? <a href="login.php" class="text-decoration-none fw-bold" style="color: #a67c52;">Masuk</a></small></div>
            </form>
        </div>
    </div>
</div>
</body>
</html>