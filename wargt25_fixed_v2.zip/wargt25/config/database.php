<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_toko";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    http_response_code(500);
    die("Koneksi database gagal. Pastikan MySQL/XAMPP aktif dan database <b>db_toko</b> sudah dibuat.");
}

mysqli_set_charset($conn, 'utf8mb4');
?>
