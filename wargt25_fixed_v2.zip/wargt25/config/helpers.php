<?php
/**
 * Helper umum Wargt25. Dirancang supaya project tetap jalan
 * pada database lama yang menyimpan kategori langsung di tb_produk.kategori.
 */

if (!function_exists('wg_default_categories')) {
    function wg_default_categories(): array
    {
        return [
            'Makanan Berat',
            'Bakar-bakaran',
            'Nasi Nasian',
            'Goreng-gorengan',
            'Snack',
            'Minuman Hangat',
            'Minuman Biasa',
            'Minuman Es',
            'Aneka Jus',
        ];
    }
}

if (!function_exists('wg_table_exists')) {
    function wg_table_exists($conn, string $table): bool
    {
        $safe = mysqli_real_escape_string($conn, $table);
        $result = mysqli_query($conn, "SHOW TABLES LIKE '$safe'");
        return $result && mysqli_num_rows($result) > 0;
    }
}

if (!function_exists('wg_ensure_category_table')) {
    function wg_ensure_category_table($conn): bool
    {
        $sql = "CREATE TABLE IF NOT EXISTS kategori (
            id_kategori INT AUTO_INCREMENT PRIMARY KEY,
            nama_kategori VARCHAR(100) NOT NULL,
            slug VARCHAR(100) NOT NULL,
            UNIQUE KEY uq_kategori_slug (slug)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

        if (!mysqli_query($conn, $sql)) {
            return false;
        }

        foreach (wg_default_categories() as $nama) {
            $escNama = mysqli_real_escape_string($conn, $nama);
            $slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $nama), '-'));
            $escSlug = mysqli_real_escape_string($conn, $slug);
            mysqli_query($conn, "INSERT IGNORE INTO kategori (nama_kategori, slug) VALUES ('$escNama', '$escSlug')");
        }
        return true;
    }
}

if (!function_exists('wg_get_categories')) {
    function wg_get_categories($conn): array
    {
        if (wg_ensure_category_table($conn)) {
            $result = mysqli_query($conn, "SELECT id_kategori, nama_kategori, slug FROM kategori ORDER BY id_kategori ASC");
            if ($result) {
                $items = [];
                while ($row = mysqli_fetch_assoc($result)) {
                    $items[] = $row;
                }
                if ($items) {
                    return $items;
                }
            }
        }

        $items = [];
        foreach (wg_default_categories() as $i => $nama) {
            $items[] = [
                'id_kategori' => $i + 1,
                'nama_kategori' => $nama,
                'slug' => strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $nama), '-')),
            ];
        }
        return $items;
    }
}

if (!function_exists('wg_product_image')) {
    function wg_product_image(?string $image, int $width = 600): string
    {
        $image = trim((string)$image);
        if ($image !== '') {
            if (filter_var($image, FILTER_VALIDATE_URL)) {
                return $image;
            }
            $local = ltrim($image, '/');
            if (strpos($local, 'assets/img/') === 0) {
                $public = $local;
                $disk = __DIR__ . '/../' . $local;
            } else {
                $filename = basename($local);
                $public = 'assets/img/' . $filename;
                $disk = __DIR__ . '/../assets/img/' . $filename;
            }
            if (is_file($disk)) {
                return $public;
            }
        }
        return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w={$width}&auto=format&fit=crop";
    }
}

if (!function_exists('wg_product_image_admin')) {
    function wg_product_image_admin(?string $image): string
    {
        $image = trim((string)$image);
        if ($image === '') return '';
        if (filter_var($image, FILTER_VALIDATE_URL)) return $image;
        $local = ltrim($image, '/');
        $filename = basename($local);
        if (is_file(__DIR__ . '/../assets/img/' . $filename)) {
            return '../assets/img/' . $filename;
        }
        return 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=240&auto=format&fit=crop';
    }
}

if (!function_exists('wg_detect_columns')) {
    function wg_detect_columns($conn, string $table): array
    {
        $columns = [];
        if (!wg_table_exists($conn, $table)) return $columns;
        $result = mysqli_query($conn, "SHOW COLUMNS FROM `$table`");
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $columns[] = strtolower($row['Field']);
            }
        }
        return $columns;
    }
}

if (!function_exists('wg_flash_redirect')) {
    function wg_flash_redirect(string $url, string $message): void
    {
        $safeUrl = json_encode($url, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $safeMessage = json_encode($message, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        echo "<script>alert($safeMessage); window.location.href=$safeUrl;</script>";
        exit;
    }
}
