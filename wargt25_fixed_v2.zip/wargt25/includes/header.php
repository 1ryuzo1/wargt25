<?php
if (session_status() == PHP_SESSION_NONE) { session_start(); }
include_once __DIR__ . '/../config/database.php';
include_once __DIR__ . '/../config/helpers.php';

if(!function_exists('rupiah')) {
    function rupiah($angka) {
        return "Rp " . number_format($angka, 0, ',', '.');
    }
}

// Helper: ikon kategori & efek asap untuk kartu menu bertema kuliner
if(!function_exists('wg_kategori_icon')) {
    function wg_kategori_icon($kategori) {
        $map = [
            'Bakar-bakaran'   => 'bi-fire',
            'Goreng-gorengan' => 'bi-egg-fried',
            'Makanan Berat'   => 'bi-egg-fried',
            'Nasi Nasian'     => 'bi-basket2-fill',
            'Snack'           => 'bi-cookie',
            'Minuman Hangat'  => 'bi-cup-hot-fill',
            'Minuman Biasa'   => 'bi-cup-straw',
            'Minuman Es'      => 'bi-snow2',
            'Aneka Jus'       => 'bi-cup-straw',
        ];
        return $map[$kategori] ?? 'bi-stars';
    }
}
if(!function_exists('wg_kategori_steam')) {
    function wg_kategori_steam($kategori) {
        return (stripos($kategori, 'bakar') !== false || stripos($kategori, 'goreng') !== false || stripos($kategori, 'hangat') !== false);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wargt25 - Kuliner Premium Nusantara</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- LIBRARY ANIMASI: AOS (Animate On Scroll) CSS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

    <!-- THEME: Design system, animasi, & interaksi premium Wargt25 -->
    <link rel="stylesheet" href="assets/css/theme.css">
</head>
<body>
<div id="wg-progress"></div>
<div id="wg-preloader">
    <div class="text-center">
        <div class="wg-loader-mark">Wargt<span>25</span></div>
        <div class="wg-loader-bar"></div>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-wargt">
    <div class="container">
        <a class="navbar-brand brand-wargt" href="index.php">Wargt<span>25</span></a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navWargtMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navWargtMenu">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link nav-link-wargt active" href="index.php">Beranda</a></li>
                <li class="nav-item"><a class="nav-link nav-link-wargt" href="menu.php">Menu Kuliner</a></li>
                <li class="nav-item"><a class="nav-link nav-link-wargt" href="index.php#kategori">Kategori Menu</a></li>
            </ul>
            <div class="d-flex align-items-center">
                <!-- Keranjang Belanjaan Berbasis Jumlah Qty Total Item -->
                <a href="keranjang.php" class="cart-icon-btn">
                    <i class="bi bi-bag-dash-fill"></i>
                    <?php $wg_cart_count = 0;
                    if (isset($_SESSION['keranjang']) && is_array($_SESSION['keranjang'])) {
                        foreach ($_SESSION['keranjang'] as $qty) {
                            $wg_cart_count += is_array($qty) ? (int)($qty['qty'] ?? 0) : (int)$qty;
                        }
                    } ?>
                    <span class="cart-badge<?= $wg_cart_count > 0 ? ' has-items' : '' ?>">
                        <?= $wg_cart_count; ?>
                    </span>
                </a>
                
                <?php if(isset($_SESSION['role'])): ?>
                    <!-- KONDISI A: JIKA SUDAH LOGIN -->
                    <?php if($_SESSION['role'] == 'admin'): ?>
                        <!-- Login Sebagai Admin -->
                        <a href="admin/index.php" class="btn btn-wargt-outline me-2"><i class="bi bi-speedometer2 me-1"></i> Dashboard Admin</a>
                    <?php else: ?>
                        <!-- Login Sebagai Pelanggan biasa -->
                        <a href="profil.php" class="btn btn-wargt-primary me-2"><i class="bi bi-person me-1"></i> Profil</a>
                    <?php endif; ?>
                    
                    <!-- Tombol Logout Universal -->
                    <a href="auth/logout.php" class="btn btn-light border rounded-pill px-3 text-danger btn-sm" title="Keluar Sesi"><i class="bi bi-box-arrow-right"></i></a>
                    
                <?php else: ?>
                    <!-- KONDISI B: JIKA BELUM LOGIN SAMA SEKALI -->
                    <a href="auth/login.php" class="btn btn-wargt-primary">Masuk Akun</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>