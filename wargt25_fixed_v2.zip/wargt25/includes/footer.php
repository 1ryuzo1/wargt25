<footer class="mt-5 pt-5 pb-4" style="background-color: #273526; color: #fcfaf6; border-top: 3px solid #a67c52;">
    <div class="container">
        <div class="row g-4">
            <!-- Kolom 1: Informasi Toko & Google Maps -->
            <div class="col-lg-4 col-md-6" data-aos="fade-up">
                <h5 class="fw-bold text-white mb-3" style="letter-spacing: -0.02em;">Wargt<span style="color: #a67c52;">25</span></h5>
                <p class="small text-white-50 mb-3">Kuliner Premium Nusantara dengan cita rasa autentik dan kualitas terbaik.</p>
                <p class="small mb-3">
                    <i class="bi bi-geo-alt-fill me-2 text-warning"></i> Jl. Tentara Pelajar, Kota Cirebon, Jawa Barat
                </p>
                <!-- Embed Google Maps Kota Cirebon Jl Tentara Pelajar -->
                <div class="rounded overflow-hidden shadow-sm" style="height: 150px; border: 1px solid rgba(255,255,255,0.1);">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3962.4346914902195!2d108.55225107572626!3d-6.716656665668383!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2bee26fae3d09a27%3A0x633d7b8a7c2c11bb!2sJl.%20Tentara%20Pelajar%2C%20Kejaksan%2C%20Kec.%20Kejaksan%2C%20Kota%20Cirebon%2C%20Jawa%20Barat!5e0!3m2!1sid!2sid!4v1710000000000!5m2!1sid!2sid" 
                        width="100%" 
                        height="100%" 
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy" 
                        referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                </div>
            </div>

            <!-- Kolom 2: Kontak Lengkap -->
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                <h5 class="fw-bold text-white mb-3">Kontak Hubungi</h5>
                <ul class="list-unstyled small text-white-50">
                    <li class="mb-2">
                        <i class="bi bi-telephone-fill me-2 text-warning"></i> WhatsApp: 
                        <a href="https://wa.me/6281234567890" target="_blank" class="text-white-50 text-decoration-none">+62 812-3456-7890</a>
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-envelope-fill me-2 text-warning"></i> Email: 
                        <a href="mailto:support@wargt25.com" class="text-white-50 text-decoration-none">support@wargt25.com</a>
                    </li>
                    <li class="mb-2">
                        <i class="bi bi-clock-fill me-2 text-warning"></i> Jam Operasional:<br>
                        <span class="ms-4">Setiap Hari (10:00 - 22:00 WIB)</span>
                    </li>
                </ul>
                <div class="mt-3 text-white-50 small">Media sosial Wargt25 segera hadir.</div>
            </div>

            <!-- Kolom 3: Laporan Bug & Masalah -->
            <div class="col-lg-4 col-md-12" data-aos="fade-up" data-aos-delay="200">
                <h5 class="fw-bold text-white mb-3">Laporkan Masalah / Bug</h5>
                <p class="small text-white-50 mb-2">Menemukan error pada sistem? Kirim laporan cepat di bawah ini:</p>
                <form action="proses_laporan.php" method="POST">
                    <div class="input-group input-group-sm mb-2">
                        <input type="email" name="email_pelapor" class="form-control" placeholder="Email kamu" required style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff;">
                    </div>
                    <div class="mb-2">
                        <textarea name="deskripsi_bug" class="form-control form-control-sm" rows="2" placeholder="Jelaskan kendala atau bug..." required style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff;"></textarea>
                    </div>
                    <button type="submit" class="btn btn-sm w-100" style="background-color: #a67c52; color: #fff; font-weight: 600;">Kirim Laporan</button>
                </form>
            </div>
        </div>

        <hr class="my-4" style="border-color: rgba(255,255,255,0.1);">

        <!-- Baris Paling Bawah: Copyright -->
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start small text-white-50">
                &copy; <?= date('Y'); ?> <span class="text-white fw-semibold">Wargt25</span>. Hak Cipta Dilindungi Undang-Undang.
            </div>
            <div class="col-md-6 text-center text-md-end small text-white-50 mt-2 mt-md-0">
                Made with <i class="bi bi-heart-fill text-danger"></i> for Premium Culinary Experience
            </div>
        </div>
    </div>
</footer>

<!-- Tombol Kembali ke Atas -->
<button id="wg-top" aria-label="Kembali ke atas"><i class="bi bi-arrow-up"></i></button>

<!-- SCRIPT AOS DAN BOOTSTRAP -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    if (window.AOS && typeof AOS.init === 'function') {
        AOS.init({ duration: 800, once: true, easing: 'ease-in-out' });
    }
</script>
<!-- THEME: interaksi premium (tilt card, navbar shrink, ripple, back-to-top) -->
<script src="assets/js/theme.js"></script>
</body>
</html>