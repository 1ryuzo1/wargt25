<?php
// Alur checkout utama berada di keranjang.php dan proses_checkout.php.
header("Location: keranjang.php");
exit;
